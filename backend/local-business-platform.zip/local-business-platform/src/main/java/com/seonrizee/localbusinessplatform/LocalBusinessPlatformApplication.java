package com.seonrizee.localbusinessplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalBusinessPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalBusinessPlatformApplication.class, args);
	}

}
